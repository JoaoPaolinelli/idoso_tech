package johnny_tech.idosotech.app_idoso_tech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AplicativoIdosoTechApplicationTests {

	@Test
	void contextLoads() {
	}

}
