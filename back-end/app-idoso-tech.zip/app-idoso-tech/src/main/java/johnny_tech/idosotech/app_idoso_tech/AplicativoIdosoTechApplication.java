package johnny_tech.idosotech.app_idoso_tech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AplicativoIdosoTechApplication {

	public static void main(String[] args) {
		SpringApplication.run(AplicativoIdosoTechApplication.class, args);
	}

}
